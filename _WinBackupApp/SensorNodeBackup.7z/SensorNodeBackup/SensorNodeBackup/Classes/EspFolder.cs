﻿namespace SensorNodeBackup.Classes
{
    public class EspFolder
    {
        public EspFolder(string name)
        {
            Name = name;
        }

        public string Name { get; set; }

        public List<string> Files { get; set; } = new List<string>();

        public override string ToString()
            => Name;
    }
}
