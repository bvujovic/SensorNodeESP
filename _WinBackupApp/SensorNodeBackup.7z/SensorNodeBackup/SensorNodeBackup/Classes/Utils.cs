﻿using System.Diagnostics;

namespace SensorNodeBackup.Classes
{
    public static class Utils
    {

        /// <summary>Prikazuje modalni MessageBox.</summary>
        public static DialogResult ShowMbox(string message, string title, bool toClipboard = false)
        {
            if (toClipboard)
                Clipboard.SetText(title + Environment.NewLine + message);
            return MessageBox.Show
            (
              message, title, MessageBoxButtons.OK, MessageBoxIcon.Information
            );
        }

        /// <summary>Opens file or folder with given path.</summary>
        public static void OpenFromPC(string path)
        {
            Process.Start(new ProcessStartInfo()
            {
                FileName = path,
                UseShellExecute = true,
                Verb = "open"
            });
        }

        public static string[] SplitToLines(this string s)
            => s.Split(['\r', '\n'], StringSplitOptions.RemoveEmptyEntries);

        public static void SaveToPC(string pcFile, string contentESP)
        {
            if (!File.Exists(pcFile))
                File.WriteAllText(pcFile, contentESP);
            else
            {
                var firstTimeESP = FirstTime(contentESP);
                var contentPC = File.ReadAllText(pcFile);
                var firstTimePC = FirstTime(contentPC);
                if (string.IsNullOrEmpty(firstTimeESP) || string.IsNullOrEmpty(firstTimePC)
                    || firstTimeESP == firstTimePC)
                    File.WriteAllText(pcFile, contentESP);
                else
                {
                    var lines = new List<string>();
                    lines.AddRange(contentESP.SplitToLines());
                    lines.AddRange(contentPC.SplitToLines());
                    lines = lines.Select(it => it.Trim()).Distinct().ToList();
                    lines.Sort();
                    File.WriteAllText(pcFile, string.Join(Environment.NewLine, lines));
                }
            }
        }

        private static string? FirstTime(string content)
        {
            if (string.IsNullOrEmpty(content))
                return null;
            var idx = content.IndexOf('\t');
            if (idx < 0)
                return null;
            else
                return content.Substring(0, idx);
        }
    }
}
