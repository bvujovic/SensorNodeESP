﻿namespace SensorNodeBackup.Classes
{
    public static class WebApi
    {
        /// <summary>Dohvata (GET) JSON podatke od JISP WebAPI-a.</summary>
        /// <see cref="https://stackoverflow.com/questions/14627399/setting-authorization-header-of-httpclient"/>
        public static async Task<string> Get(string url)
        {
            return await GetHttpClient().GetStringAsync(url);
        }

        private static HttpClient? httpClient = null;

        private static HttpClient GetHttpClient()
        {
            if (httpClient != null)
                return httpClient;
            httpClient = new HttpClient() { Timeout = TimeSpan.FromSeconds(5) };
            return httpClient;
        }
    }
}
