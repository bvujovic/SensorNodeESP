﻿namespace SensorNodeBackup
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            txtDataFolder = new TextBox();
            btnGotoDataFolder = new Button();
            scMain = new SplitContainer();
            lstEspFiles = new ListBox();
            ctxEspFiles = new ContextMenuStrip(components);
            tsmiEspFilesLoadContent = new ToolStripMenuItem();
            lstEspFolders = new ListBox();
            ctxEspFolders = new ContextMenuStrip(components);
            tsmiEspFoldersLoadFiles = new ToolStripMenuItem();
            label2 = new Label();
            lstPcFiles = new ListBox();
            lstPcFolders = new ListBox();
            label3 = new Label();
            tsmiCreatePCFolders = new ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)scMain).BeginInit();
            scMain.Panel1.SuspendLayout();
            scMain.Panel2.SuspendLayout();
            scMain.SuspendLayout();
            ctxEspFiles.SuspendLayout();
            ctxEspFolders.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 34);
            label1.Name = "label1";
            label1.Size = new Size(88, 20);
            label1.TabIndex = 1;
            label1.Text = "Data folder:";
            // 
            // txtDataFolder
            // 
            txtDataFolder.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            txtDataFolder.Location = new Point(106, 31);
            txtDataFolder.Name = "txtDataFolder";
            txtDataFolder.ReadOnly = true;
            txtDataFolder.Size = new Size(721, 27);
            txtDataFolder.TabIndex = 2;
            // 
            // btnGotoDataFolder
            // 
            btnGotoDataFolder.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnGotoDataFolder.Location = new Point(833, 31);
            btnGotoDataFolder.Name = "btnGotoDataFolder";
            btnGotoDataFolder.Size = new Size(39, 27);
            btnGotoDataFolder.TabIndex = 3;
            btnGotoDataFolder.Text = "...";
            btnGotoDataFolder.UseVisualStyleBackColor = true;
            btnGotoDataFolder.Click += BtnGotoDataFolder_Click;
            // 
            // scMain
            // 
            scMain.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            scMain.Location = new Point(12, 64);
            scMain.Name = "scMain";
            // 
            // scMain.Panel1
            // 
            scMain.Panel1.Controls.Add(lstEspFiles);
            scMain.Panel1.Controls.Add(lstEspFolders);
            scMain.Panel1.Controls.Add(label2);
            // 
            // scMain.Panel2
            // 
            scMain.Panel2.Controls.Add(lstPcFiles);
            scMain.Panel2.Controls.Add(lstPcFolders);
            scMain.Panel2.Controls.Add(label3);
            scMain.Size = new Size(860, 408);
            scMain.SplitterDistance = 428;
            scMain.TabIndex = 4;
            // 
            // lstEspFiles
            // 
            lstEspFiles.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lstEspFiles.ContextMenuStrip = ctxEspFiles;
            lstEspFiles.FormattingEnabled = true;
            lstEspFiles.ItemHeight = 20;
            lstEspFiles.Location = new Point(3, 113);
            lstEspFiles.Name = "lstEspFiles";
            lstEspFiles.SelectionMode = SelectionMode.MultiExtended;
            lstEspFiles.Size = new Size(120, 284);
            lstEspFiles.TabIndex = 2;
            lstEspFiles.DoubleClick += LstEspFiles_DoubleClick;
            // 
            // ctxEspFiles
            // 
            ctxEspFiles.Items.AddRange(new ToolStripItem[] { tsmiEspFilesLoadContent });
            ctxEspFiles.Name = "ctxEspFolders";
            ctxEspFiles.Size = new Size(168, 26);
            // 
            // tsmiEspFilesLoadContent
            // 
            tsmiEspFilesLoadContent.Name = "tsmiEspFilesLoadContent";
            tsmiEspFilesLoadContent.Size = new Size(167, 22);
            tsmiEspFilesLoadContent.Text = "Load File Content";
            tsmiEspFilesLoadContent.Click += TsmiEspFilesLoadContent_Click;
            // 
            // lstEspFolders
            // 
            lstEspFolders.ContextMenuStrip = ctxEspFolders;
            lstEspFolders.FormattingEnabled = true;
            lstEspFolders.ItemHeight = 20;
            lstEspFolders.Location = new Point(3, 23);
            lstEspFolders.Name = "lstEspFolders";
            lstEspFolders.SelectionMode = SelectionMode.MultiExtended;
            lstEspFolders.Size = new Size(120, 84);
            lstEspFolders.TabIndex = 1;
            lstEspFolders.SelectedIndexChanged += LstEspFolders_SelectedIndexChanged;
            lstEspFolders.DoubleClick += LstEspFolders_DoubleClick;
            // 
            // ctxEspFolders
            // 
            ctxEspFolders.Items.AddRange(new ToolStripItem[] { tsmiEspFoldersLoadFiles, tsmiCreatePCFolders });
            ctxEspFolders.Name = "ctxEspFolders";
            ctxEspFolders.Size = new Size(181, 70);
            // 
            // tsmiEspFoldersLoadFiles
            // 
            tsmiEspFoldersLoadFiles.Name = "tsmiEspFoldersLoadFiles";
            tsmiEspFoldersLoadFiles.Size = new Size(180, 22);
            tsmiEspFoldersLoadFiles.Text = "Load Files";
            tsmiEspFoldersLoadFiles.Click += TsmiEspFoldersLoadFiles_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(3, 0);
            label2.Name = "label2";
            label2.Size = new Size(33, 20);
            label2.TabIndex = 0;
            label2.Text = "ESP";
            // 
            // lstPcFiles
            // 
            lstPcFiles.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left;
            lstPcFiles.ContextMenuStrip = ctxEspFiles;
            lstPcFiles.FormattingEnabled = true;
            lstPcFiles.ItemHeight = 20;
            lstPcFiles.Location = new Point(3, 113);
            lstPcFiles.Name = "lstPcFiles";
            lstPcFiles.SelectionMode = SelectionMode.MultiExtended;
            lstPcFiles.Size = new Size(120, 284);
            lstPcFiles.TabIndex = 3;
            lstPcFiles.DoubleClick += LstPcFiles_DoubleClick;
            // 
            // lstPcFolders
            // 
            lstPcFolders.FormattingEnabled = true;
            lstPcFolders.ItemHeight = 20;
            lstPcFolders.Location = new Point(3, 23);
            lstPcFolders.Name = "lstPcFolders";
            lstPcFolders.SelectionMode = SelectionMode.MultiExtended;
            lstPcFolders.Size = new Size(120, 84);
            lstPcFolders.TabIndex = 2;
            lstPcFolders.SelectedIndexChanged += LstPcFolders_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(3, 0);
            label3.Name = "label3";
            label3.Size = new Size(26, 20);
            label3.TabIndex = 1;
            label3.Text = "PC";
            // 
            // tsmiCreatePCFolders
            // 
            tsmiCreatePCFolders.Name = "tsmiCreatePCFolders";
            tsmiCreatePCFolders.Size = new Size(180, 22);
            tsmiCreatePCFolders.Text = "Create PC Folders";
            tsmiCreatePCFolders.Click += TsmiCreatePCFolders_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(884, 484);
            Controls.Add(scMain);
            Controls.Add(btnGotoDataFolder);
            Controls.Add(txtDataFolder);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "SensorNode: Backup/Restore";
            Load += Form1_Load;
            scMain.Panel1.ResumeLayout(false);
            scMain.Panel1.PerformLayout();
            scMain.Panel2.ResumeLayout(false);
            scMain.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)scMain).EndInit();
            scMain.ResumeLayout(false);
            ctxEspFiles.ResumeLayout(false);
            ctxEspFolders.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private TextBox txtDataFolder;
        private Button btnGotoDataFolder;
        private SplitContainer scMain;
        private Label label2;
        private Label label3;
        private ListBox lstEspFolders;
        private ListBox lstPcFolders;
        private ListBox lstEspFiles;
        private ContextMenuStrip ctxEspFolders;
        private ToolStripMenuItem tsmiEspFoldersLoadFiles;
        private ContextMenuStrip ctxEspFiles;
        private ToolStripMenuItem tsmiEspFilesLoadContent;
        private ListBox lstPcFiles;
        private ToolStripMenuItem tsmiCreatePCFolders;
    }
}
