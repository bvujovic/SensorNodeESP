using SensorNodeBackup.Classes;

namespace SensorNodeBackup
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private DirectoryInfo? diData = null;
        private const string dataFolderName = "data";

        private async void Form1_Load(object sender, EventArgs e)
        {
            var clrInit = lstEspFolders.BackColor;
            lstEspFolders.BackColor = Color.Red;
            try
            {
                if (!Directory.Exists(dataFolderName))
                    diData = Directory.CreateDirectory(dataFolderName);
                else
                    diData = new DirectoryInfo(dataFolderName);
                txtDataFolder.Text = diData.FullName;

                var folders = await WebApi.Get("http://192.168.0.80/log?list=dirs");
                lstEspFolders.Items.Clear();
                foreach (var folder in folders.Trim().Split())
                    lstEspFolders.Items.Add(new EspFolder(folder));
                lstPcFolders.Items.AddRange(diData.EnumerateDirectories().Select(it => it.Name).ToArray());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            lstEspFolders.BackColor = clrInit;
        }

        private void BtnTest_Click(object sender, EventArgs e)
        {
            MessageBox.Show(lstEspFolders.Focused.ToString());
        }

        private void BtnGotoDataFolder_Click(object sender, EventArgs e)
        {
            try
            {
                if (diData != null)
                    Utils.OpenFromPC(diData.FullName);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private async void TsmiEspFoldersLoadFiles_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (var folder in lstEspFolders.SelectedItems.Cast<EspFolder>())
                {
                    var files = await WebApi.Get("http://192.168.0.80/log?list=files&dir=/" + folder);
                    folder.Files.Clear();
                    folder.Files.AddRange(files.Trim().Split());
                }
                LstEspFolders_SelectedIndexChanged(lstEspFolders, EventArgs.Empty);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private void LstEspFolders_DoubleClick(object sender, EventArgs e)
            => TsmiEspFoldersLoadFiles_Click(lstEspFolders, EventArgs.Empty);

        private async void TsmiEspFilesLoadContent_Click(object sender, EventArgs e)
        {
            var clrInit = lstEspFiles.BackColor;
            lstEspFiles.BackColor = Color.Red;
            try
            {
                var folder = lstEspFolders.SelectedItem as EspFolder;
                var pcFolder = GetPcFolder();
                if (pcFolder == null)
                    return;
                if (!Directory.Exists(pcFolder))
                    Directory.CreateDirectory(pcFolder);
                foreach (var file in lstEspFiles.SelectedItems.Cast<string>())
                {
                    // http://192.168.0.80/log?list=file&name=/2024_12/21_Sat.log
                    var url = $"http://192.168.0.80/log?list=file&name=/{folder}/{file}";
                    var content = (await WebApi.Get(url)).Trim();
                    var pcFile = Path.Combine(pcFolder, file);
                    Utils.SaveToPC(pcFile, content);
                }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            lstEspFiles.BackColor = clrInit;
        }

        private void LstEspFiles_DoubleClick(object sender, EventArgs e)
            => TsmiEspFilesLoadContent_Click(lstEspFolders, EventArgs.Empty);

        private void LstEspFolders_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstEspFiles.Items.Clear();
            if (lstEspFolders.SelectedItems.Count != 1)
                return;
            var folder = lstEspFolders.SelectedItem as EspFolder;
            if (folder != null)
            {
                if (folder.Files != null)
                    lstEspFiles.Items.AddRange(folder.Files.ToArray());

                for (int i = 0; i < lstPcFolders.Items.Count; i++)
                    if (lstPcFolders.Items[i].ToString() == folder.Name)
                        lstPcFolders.SelectedIndex = i;
            }
        }

        private void LstPcFolders_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var pcFolder = GetPcFolder();
                var diFolder = new DirectoryInfo(pcFolder);
                lstPcFiles.Items.Clear();
                lstPcFiles.Items.AddRange(diFolder.EnumerateFiles().Select(it => it.Name).ToArray());
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }

        private string GetPcFolder()
        {
            const string msg = "PC folder is not selected.";
            if (lstPcFolders.SelectedItems.Count != 1)
                throw new Exception(msg);
            if (diData == null || lstPcFolders.SelectedItem is not string folder)
                throw new Exception(msg);
            return Path.Combine(diData.FullName, folder);
        }

        private void LstPcFiles_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                var pcFolder = GetPcFolder();
                if (lstPcFiles.SelectedItem == null)
                    return;
                var pcFile = lstPcFiles.SelectedItem.ToString();
                Utils.OpenFromPC(Path.Combine(pcFolder, pcFile));
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
